<template>
  <div>
    <img src="@/assets/img/main_img.jpg">
</div>
</template>

<script>
export default {

}
</script>

<style scoped>
div{
  position:absolute;
  top: 0px;
  left: 0px;
  z-index: 1;
}
img{
    width: 100%;
}
</style>