<template>
  <div>
    <h1>마이페이지입니다.</h1>
    <router-link to="/update-info">회원정보 수정</router-link>
    <router-view></router-view>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>