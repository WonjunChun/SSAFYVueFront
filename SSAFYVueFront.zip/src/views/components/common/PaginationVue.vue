<template>
  <div>PaginationVue</div>
</template>

<script>
export default {

}
</script>

<style>

</style>