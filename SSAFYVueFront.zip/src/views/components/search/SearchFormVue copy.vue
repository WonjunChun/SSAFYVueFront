<template>
  <div>
    <form class="form">
      <div class="row">
        <div class="col form-group">
          <label for="category-select" class="form-label">Category</label>
          <select class="form-select" id="category-select" disabled> 
            <option>Default select</option>
          </select>
        </div>
        <div class="col form-group">
          <label for="category-select" class="form-label">Category</label>
          <select class="form-select" id="category-select" disabled> 
            <option>Default select</option>
          </select>
        </div>
        <div class="col form-group">
          <label for="category-select" class="form-label">Category</label>
          <select class="form-select" id="category-select" disabled> 
            <option>Default select</option>
          </select>
        </div>
        
      </div>
      <div class="row">
        <!-- <div class="col">
          <input type="text" class="form-control" id="formGroupExampleInput" placeholder="Example input">
        </div> -->
        <div class="col">
          <label for="attraction-title" class="form-label">Category</label>
          <div class="input-group mb-3">
            <input type="text" id="attraction-title" class="form-control" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="button-addon2">
            <button class="btn btn-outline-secondary" type="button" id="button-addon2">Button</button>
          </div>
        </div>
      </div>

    </form>
    
  </div>
</template>

<script>


export default {

}
</script>

<style scoped>
</style>